# Publish this GitHub portfolio

## GitHub profile README

1. Sign in to GitHub and create a **public** repository with a name exactly matching your GitHub username.
2. Add the included `README.md` at the repository root.
3. Replace `YOUR-GITHUB-USERNAME` and the LinkedIn placeholder with your actual profile links.

GitHub will display that repository's README on your profile.

## Portfolio website

1. Create a repository for the website and add `index.html` at the repository root.
2. Open **Settings → Pages**.
3. Under build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. GitHub will show the published URL in the Pages section after deployment completes.

Before making the repository public, review the contact details and project descriptions. Only add code samples you own and may share. This package contains no employer source code.
